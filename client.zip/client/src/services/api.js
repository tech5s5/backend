const API_URL = 'YOUR_API_ENDPOINT'; // Replace with your actual API endpoint

export async function simplifyText(text) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text }),
    });

    if (!response.ok) {
      throw new Error('Failed to simplify text');
    }

    const data = await response.json();
    return data.simplifiedText;
  } catch (error) {
    console.error('Error simplifying text:', error);
    throw error;
  }
} 